  package javaapplication11;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Employee extends JFrame {
    private JPanel contentPane;
    private JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Employee().setVisible(true));
    }

    public Employee() {
        setTitle("Employee Information");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(430, 200, 1000, 600);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        table = new JTable();
        JScrollPane jsp = new JScrollPane(table);
        jsp.setBounds(20, 20, 945, 460);
        contentPane.add(jsp);

        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.setBounds(350, 510, 120, 30);
        btnLoadData.setBackground(Color.BLACK);
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.addActionListener(e -> {
            try {
                conn c = new conn();
                ResultSet rs = c.s.executeQuery("select * from employee");
                String[] cols = {"Name", "Age", "Gender", "Job", "Salary", "Phone", "Email", "Aadhar"};
                DefaultTableModel model = new DefaultTableModel(cols, 0);
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)
                    });
                }
                table.setModel(model);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        });
        contentPane.add(btnLoadData);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(510, 510, 120, 30);
        btnBack.setBackground(Color.BLACK);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> {
            new Reception().setVisible(true);
            dispose();
        });
        contentPane.add(btnBack);
    }
}