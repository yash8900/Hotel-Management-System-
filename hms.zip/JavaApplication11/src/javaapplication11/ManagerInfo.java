package javaapplication11;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class ManagerInfo extends JFrame {
    private JPanel contentPane;
    private JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new ManagerInfo().setVisible(true));
    }

    public ManagerInfo() {
        setTitle("Manager Information");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(430, 200, 1000, 600);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 945, 450);
        contentPane.add(scrollPane);

        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.setBounds(350, 500, 120, 30);
        btnLoadData.setBackground(Color.BLACK);
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.addActionListener(e -> {
            try {
                conn c = new conn();
                String query = "select * from employee where job = 'Manager'";
                ResultSet rs = c.s.executeQuery(query);

                String[] cols = {"Name", "Age", "Gender", "Job", "Salary", "Phone", "Email", "Aadhar"};
                DefaultTableModel model = new DefaultTableModel(cols, 0);

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
                        rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8)
                    });
                }
                table.setModel(model);

                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(null, "No managers found in database.");
                }
            } catch (Exception e1) {
                e1.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database Error: " + e1.getMessage());
            }
        });
        contentPane.add(btnLoadData);

        JButton btnExit = new JButton("Back");
        btnExit.setBounds(510, 500, 120, 30);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        btnExit.addActionListener(e -> {
            new Reception().setVisible(true);
            dispose();
        });
        contentPane.add(btnExit);
    }
}