package javaapplication11;

import java.sql.*;
import javax.swing.JOptionPane;

public class conn {
    Connection c;
    Statement s;
    public static String lastError = "";

    public conn() {
        try {
            lastError = "";
            Class.forName("com.mysql.cj.jdbc.Driver");
            c = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/hotelmanagementsystem?useSSL=false&allowPublicKeyRetrieval=true",
                "root",
                "Admin@123"
            );
            c.setAutoCommit(true);
            s = c.createStatement();
        } catch (Exception e) {
            lastError = e.toString();
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "DB ERROR: " + e.toString());
        }
    }

    public static void main(String[] args) {
        conn obj = new conn();
        if (obj.s != null) {
            JOptionPane.showMessageDialog(null, "CONNECTED! JDBC bilkul sahi hai.");
        }
    }
}