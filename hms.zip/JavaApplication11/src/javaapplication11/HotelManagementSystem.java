package javaapplication11;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class HotelManagementSystem extends JFrame implements ActionListener {

    JLabel l1, lid;
    JButton b1;
    Timer timer;

    public HotelManagementSystem() {
        setSize(1366, 430);
        setLayout(null);
        setLocation(300, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        b1 = new JButton("Next");
        b1.setBackground(Color.WHITE);
        b1.setForeground(Color.BLACK);
        b1.setBounds(1170, 325, 150, 50);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("javaapplication11/icons/first.jpg"));
        Image i3 = i1.getImage().getScaledInstance(1366, 390, Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        l1 = new JLabel(i2);
        l1.setBounds(0, 0, 1366, 390);

        lid = new JLabel("HOTEL MANAGEMENT SYSTEM");
        lid.setBounds(30, 300, 1500, 100);
        lid.setFont(new Font("serif", Font.PLAIN, 70));
        lid.setForeground(Color.RED);
        l1.add(lid);

        l1.add(b1);
        add(l1);

        b1.addActionListener(this);
        setVisible(true);

        timer = new Timer(500, e -> lid.setVisible(!lid.isVisible()));
        timer.start();
    }

    public void actionPerformed(ActionEvent ae) {
        if (timer != null) {
            timer.stop();
        }
        new Login().setVisible(true);
        this.dispose();
    }

    public static void main(String[] args) {
        new HotelManagementSystem();
    }
}