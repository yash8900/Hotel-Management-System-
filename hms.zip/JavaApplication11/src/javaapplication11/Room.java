package javaapplication11;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Room extends JFrame {
    private JPanel contentPane;
    private JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Room().setVisible(true));
    }

    public Room() {
        setTitle("Room Information");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(450, 200, 1100, 600);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("javaapplication11/icons/eight.jpg"));
        Image i3 = i1.getImage().getScaledInstance(600, 600, Image.SCALE_DEFAULT);
        JLabel l1 = new JLabel(new ImageIcon(i3));
        l1.setBounds(500, 0, 600, 600);
        contentPane.add(l1);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 20, 480, 420);
        contentPane.add(scrollPane);

        JButton btnLoadData = new JButton("Load Data");
        btnLoadData.setBounds(100, 470, 120, 30);
        btnLoadData.setBackground(Color.BLACK);
        btnLoadData.setForeground(Color.WHITE);
        btnLoadData.addActionListener(e -> {
            try {
                conn c = new conn();
                ResultSet rs = c.s.executeQuery("select * from room");
                String[] cols = {"Room Number", "Availability", "Clean Status", "Price", "Bed Type"};
                DefaultTableModel model = new DefaultTableModel(cols, 0);

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5)
                    });
                }
                table.setModel(model);

                if (model.getRowCount() == 0) {
                    JOptionPane.showMessageDialog(null, "No rooms found in database.");
                }
            } catch (Exception e1) {
                e1.printStackTrace();
                JOptionPane.showMessageDialog(null, "Database Error: " + e1.getMessage());
            }
        });
        contentPane.add(btnLoadData);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(290, 470, 120, 30);
        btnBack.setBackground(Color.BLACK);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> {
            new Reception().setVisible(true);
            dispose();
        });
        contentPane.add(btnBack);
    }
}