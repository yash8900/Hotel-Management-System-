package javaapplication11;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class Department extends JFrame {
    private JPanel contentPane;
    private JTable table;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new Department().setVisible(true));
    }

    public Department() {
        setTitle("Department Information");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(600, 200, 700, 500);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 20, 645, 360);
        contentPane.add(scrollPane);

        JButton btnLoad = new JButton("Load Data");
        btnLoad.setBounds(170, 410, 120, 30);
        btnLoad.setBackground(Color.BLACK);
        btnLoad.setForeground(Color.WHITE);
        btnLoad.addActionListener(e -> {
            try {
                conn c = new conn();
                ResultSet rs = c.s.executeQuery("select * from department");
                DefaultTableModel model = new DefaultTableModel(new String[]{"Department", "Budget"}, 0);
                while (rs.next()) {
                    model.addRow(new Object[]{rs.getString(1), rs.getString(2)});
                }
                table.setModel(model);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage());
            }
        });
        contentPane.add(btnLoad);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(400, 410, 120, 30);
        btnBack.setBackground(Color.BLACK);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> {
            new Reception().setVisible(true);
            dispose();
        });
        contentPane.add(btnBack);
    }
}