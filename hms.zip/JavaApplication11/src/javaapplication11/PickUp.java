package javaapplication11;

import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class PickUp extends JFrame {
    private JPanel contentPane;
    private JTable table;
    private Choice c1;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new PickUp().setVisible(true));
    }

    public PickUp() {
        setTitle("Pick Up Service");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(530, 200, 800, 600);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setBackground(Color.WHITE);
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblPickUpService = new JLabel("Pick Up Service");
        lblPickUpService.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblPickUpService.setBounds(90, 15, 200, 25);
        contentPane.add(lblPickUpService);

        JLabel lblTypeOfCar = new JLabel("Type of Car:");
        lblTypeOfCar.setBounds(32, 85, 89, 20);
        contentPane.add(lblTypeOfCar);

        c1 = new Choice();
        try {
            conn c = new conn();
            ResultSet rs = c.s.executeQuery("SELECT DISTINCT brand FROM driver");
            while (rs.next()) {
                c1.add(rs.getString("brand"));
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error loading car brands: " + e.getMessage());
        }
        c1.setBounds(130, 85, 160, 25);
        contentPane.add(c1);

        table = new JTable();
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 140, 745, 330);
        contentPane.add(scrollPane);

        JButton btnDisplay = new JButton("Display");
        btnDisplay.setBounds(200, 500, 120, 30);
        btnDisplay.setBackground(Color.BLACK);
        btnDisplay.setForeground(Color.WHITE);
        btnDisplay.addActionListener(e -> {
            String selectedBrand = c1.getSelectedItem();
            if (selectedBrand == null) {
                JOptionPane.showMessageDialog(null, "No drivers available in database.");
                return;
            }
            try {
                conn c = new conn();
                String sql = "SELECT * FROM driver WHERE brand = '" + selectedBrand + "'";
                ResultSet rs = c.s.executeQuery(sql);

                String[] cols = {"Name", "Age", "Gender", "Company", "Brand", "Available", "Location"};
                DefaultTableModel model = new DefaultTableModel(cols, 0);

                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString(1), rs.getString(2), rs.getString(3),
                        rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7)
                    });
                }
                table.setModel(model);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage());
            }
        });
        contentPane.add(btnDisplay);

        JButton btnBack = new JButton("Back");
        btnBack.setBounds(420, 500, 120, 30);
        btnBack.setBackground(Color.BLACK);
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> {
            new Reception().setVisible(true);
            dispose();
        });
        contentPane.add(btnBack);
    }
}